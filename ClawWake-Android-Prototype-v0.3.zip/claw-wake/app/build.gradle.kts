plugins { id("com.android.application") }

android {
    namespace = "com.clawwake.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clawwake.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-prototype"
    }
}
